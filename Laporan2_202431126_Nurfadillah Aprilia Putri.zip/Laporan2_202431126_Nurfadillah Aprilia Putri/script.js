document.addEventListener("DOMContentLoaded", function() {
  document.querySelectorAll(".problem .title").forEach(title => {
    title.addEventListener("click", () => {
      const desc = title.nextElementSibling;

      if (desc.style.display === "none") {
        if (confirm("Apakah Anda ingin menampilkan penjelasan ini?")) {
          desc.style.display = "";
        }
      } else {
        if (confirm("Apakah Anda ingin menyembunyikan penjelasan ini?")) {
          desc.style.display = "none";
        }
      }
    });
  });

  const btnMode = document.getElementById("toggleMode");
  btnMode.addEventListener("click", () => {
    document.body.classList.toggle("mode-berantakan");
  });

  document.getElementById("showImages").addEventListener("click", () => {
    window.location.href = "gambar.html";
  });
});
